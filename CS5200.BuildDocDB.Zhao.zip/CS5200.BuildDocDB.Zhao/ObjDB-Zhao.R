rootDir <- "docDB"

configDB <- function(root, path) {
  dir.create(paste(path, root, sep = "/"))
}

genObjPath <- function(root, tag) {
  objPath <- paste(root, substring(tag, 2, nchar(tag)), sep = "/")
  return (objPath)
}

getTags <- function(fileName) {
  tagVec <- vector()
  tagList <- strsplit(fileName, ' ')
  last <- length(tagList[[1]])
  tagList[[1]][last] <- strsplit(tagList[[1]][last], '[.]')[[1]][1]
  tagVec <- unlist(tagList[[1]][2:last])
  return (tagVec)
}

getFileName <- function(fileName) {
  tagVec = getTags(fileName)
  for (i in 1:length(tagVec)) {
    fileName <- sub(pattern = tagVec[i], replacement = "", fileName)
  }
  fileName <- gsub(pattern = " ", replacement = "", fileName)
  return  (fileName)
}

storeObjs <- function(folder, root, verbose) {
  files <- list.files(path = folder)
  for (i in 1:length(files)) {
    oldFileName <- files[i]
    newFileName <- getFileName(files[i])
    tag <- getTags(oldFileName)
    tagOutput <- sub(pattern = "#", replacement = "", tag)
    for (j in 1:length(tag)) {
      oldPath <- paste(folder, oldFileName, sep = "/")
      newPath <- paste(genObjPath(root, tag[j]), newFileName, sep = "/")
      tagPath <- paste(root, substring(tag[j], 2, nchar(tag[j])), sep = "/")
      print(tagPath)
      if (!dir.exists(tagPath)) {
        dir.create(tagPath)
      }
      file.copy(oldPath, newPath)
    }
    if (verbose == TRUE) {
      print(paste("Copying", newFileName, "to", tagOutput))
    }
  }
}

clearDB <- function(root) {
  files <- list.files(path = root)
  file.remove(files)
}

main <- function() {
  configDB(rootDir, "~/database/CS5200.BuildDocDB.Zhao")
  storeObjs("source", paste("~/database/CS5200.BuildDocDB.Zhao", rootDir, sep = "/"), TRUE)
  #quit()
}

main()

